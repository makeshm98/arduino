#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

#include <Arduino.h>
#include <SPI.h>

// Pin definitions
#define OLED_DC     8   // Data/Command pin
#define OLED_CS     10  // Chip Select pin
#define OLED_RST    7   // Reset pin

// Function prototypes
void oledInit();
void sendCommand(uint8_t command);
void sendData(uint8_t data);
void oledReset();
void clearDisplay(uint8_t buffer[1024]);
void updateDisplay(uint8_t buffer[1024]);
void setPixel(uint8_t buffer[1024], int x, int y, bool color);
void drawChar(uint8_t buffer[1024], int x, int y, char c);
void drawString(uint8_t buffer[1024], int x, int y, const char* str);

// Global variables
//extern uint8_t buffer[1024];
extern uint8_t textsize_x;
extern uint8_t textsize_y;

#endif // OLED_DISPLAY_H

